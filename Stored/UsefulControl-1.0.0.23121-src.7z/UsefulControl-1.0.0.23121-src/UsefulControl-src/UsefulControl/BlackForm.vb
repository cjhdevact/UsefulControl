﻿Public Class BlackForm
    Public a As Integer
    Private Sub BlackForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        a = 0
    End Sub
    Private Sub BlackForm_MouseDoubleClick(sender As System.Object, e As System.EventArgs) Handles MyBase.MouseDoubleClick
        If a = 5 Then
            Me.Close()
        Else
            a = a + 1
        End If
    End Sub
End Class