﻿Public Class FakeShutdownForm
    Public a As Integer
    Private Sub FakeShutdownForm_MouseDoubleClick(sender As System.Object, e As System.EventArgs) Handles MyBase.MouseDoubleClick
        If a = 5 Then
            Me.Close()
        Else
            a = a + 1
        End If
    End Sub
    Private Sub FakeShutdownForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        a = 0
    End Sub
    Private Sub TableLayoutPanel1_MouseDoubleClick(sender As System.Object, e As System.EventArgs) Handles TableLayoutPanel1.MouseDoubleClick
        If a = 5 Then
            Me.Close()
        Else
            a = a + 1
        End If
    End Sub

    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        Me.PictureBox1.Visible = False
        Me.Label1.Visible = False
        'Form1.ChangeMonitorState(Form1.MonitorMode.MonitorOff)
        SeewoFakeShut.Show()
        Timer1.Enabled = False
    End Sub
End Class