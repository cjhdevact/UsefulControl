﻿Public Class Form1
    <System.Runtime.InteropServices.DllImport("user32.dll")> _
    Private Shared Function SendMessage(ByVal hWnd As Integer, ByVal Msg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    End Function
    Const SC_MONITORPOWER As Integer = &HF170
    Const WM_SYSCOMMAND As Integer = &H112
    Public Enum MonitorMode As Integer
        MonitorOn = -1
        MonitorStandby = 1
        MonitorOff = 2
    End Enum
    Public Sub ChangeMonitorState(ByVal mode As MonitorMode)
        SendMessage(-1, WM_SYSCOMMAND, SC_MONITORPOWER, CInt(mode))
    End Sub
    'Private Sub MonitorOff()
    '    ChangeMonitorState(MonitorMode.MonitorOff)
    'End Sub
    'Private Sub MonitorOn()
    '    ChangeMonitorState(MonitorMode.MonitorOn)
    'End Sub
    'Private Sub MonitorStandBy()
    '    ChangeMonitorState(MonitorMode.MonitorStandby)
    'End Sub

    'powershell (Add-Type '[DllImport(\"user32.dll\")]^public static extern int SendMessage(int hWnd, int hMsg, int wParam, int lParam);' -Name a -Pas)::SendMessage(-1,0x0112,0xF170,2)
    Public a As New System.Drawing.Point
    Public ShutdownStateV As Integer
    Public RestartStateV As Integer
    Public RenS As Integer
    Public CurState As Integer
    Public MovedV As Integer
    Public UseMoveV As Integer
    Public NavTargetNames(28) As String
    Public DocTargetNames(39) As String
    'API移动窗体
    Declare Function ReleaseCapture Lib "user32" Alias "ReleaseCapture" () As Boolean
    Const SC_MOVE = &HF010&
    Const HTCAPTION = 2
    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
            ReleaseCapture()
            SendMessage(Me.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0)
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        NavTargetNames(0) = "TimeControl"
        NavTargetNames(1) = "PowerControl"
        NavTargetNames(2) = "TDocKiller"
        NavTargetNames(3) = "IBoard"
        NavTargetNames(4) = "LockTime"
        NavTargetNames(5) = "PBoard"
        NavTargetNames(6) = "LockTime2"
        NavTargetNames(7) = "PBoard2"
        NavTargetNames(8) = "TimeControl64"
        NavTargetNames(9) = "PowerControl64"
        NavTargetNames(10) = "TDocKiller64"
        NavTargetNames(11) = "IBoard64"
        NavTargetNames(12) = "LockTime64"
        NavTargetNames(13) = "PBoard64"
        NavTargetNames(14) = "LockTime264"
        NavTargetNames(15) = "PBoard264"

        NavTargetNames(16) = "PPTService"
        NavTargetNames(17) = "SeewoCore"
        NavTargetNames(18) = "SeewoFreezeUpdateAssist"
        NavTargetNames(19) = "proxyLayerService"
        NavTargetNames(20) = "ResidentSideBar.Defender"
        NavTargetNames(21) = "ResidentSideBar"
        NavTargetNames(22) = "LastContainer"
        NavTargetNames(23) = "LastContainerDaemon"
        NavTargetNames(24) = "EasiRecorder"
        NavTargetNames(25) = "seewoPincoTeacher"
        NavTargetNames(26) = "seewoPincoTeacherService"
        NavTargetNames(27) = "PincoMirror"
        NavTargetNames(28) = "SeewoService"

        DocTargetNames(0) = "WINWORD"
        DocTargetNames(1) = "EXCEL"
        DocTargetNames(2) = "POWERPNT"
        DocTargetNames(3) = "wps"
        DocTargetNames(4) = "et"
        DocTargetNames(5) = "wpp"
        DocTargetNames(6) = "wpspdf"
        DocTargetNames(7) = "wpsoffice"
        DocTargetNames(8) = "msedge"
        DocTargetNames(9) = "chrome"
        DocTargetNames(10) = "firefox"
        DocTargetNames(11) = "EasiNote"
        DocTargetNames(12) = "EasiCamera"
        DocTargetNames(13) = "Wechat"
        DocTargetNames(14) = "db"
        DocTargetNames(15) = "Cbox"
        DocTargetNames(16) = "qyplayer"
        DocTargetNames(17) = "QQLive"
        DocTargetNames(18) = "kugou"
        DocTargetNames(19) = "kuwomusic"
        DocTargetNames(20) = "wpspic"
        DocTargetNames(21) = "iexplore"
        DocTargetNames(22) = "PotPlayer"
        DocTargetNames(23) = "PotPlayerMini"
        DocTargetNames(24) = "PhotosApp"
        DocTargetNames(25) = "PhotosService"
        DocTargetNames(26) = "Microsoft.Photos"
        DocTargetNames(27) = "Microsoft.Media.Player"
        DocTargetNames(28) = "Groove"
        DocTargetNames(29) = "WindowsCamera"
        DocTargetNames(30) = "SoundRec"
        DocTargetNames(31) = "CalculatorApp"
        DocTargetNames(32) = "calc"
        DocTargetNames(33) = "notepad"
        DocTargetNames(34) = "rundll32"
        DocTargetNames(35) = "dllhost"
        DocTargetNames(36) = "mspaint"
        DocTargetNames(37) = "wmplayer"
        DocTargetNames(38) = "Video.UI"
        DocTargetNames(39) = "SnippingTool"
        '支持关闭程序列表
        'WINWORD.exe, EXCEL.exe, POWERPNT.exe, 
        'wps.exe, et.exe, wpp.exe, 
        'wpspdf.exe, wpsoffice.exe, msedge.exe, 
        'chrome.exe, firefox.exe, EasiNote.exe, 
        'EasiCamera.exe, Wechat.exe, db.exe, 
        'Cbox.exe, qyplayer.exe, QQLive.exe, 
        'kugou.exe, kuwomusic.exe, wpspic.exe, 
        'iexplore.exe, PotPlayer.exe, PotPlayerMini.exe, 
        'PhotosApp.exe, PhotosService.exe, Microsoft.Photos.exe, 
        'Microsoft.Media.Player.exe, Groove.exe, WindowsCamera.exe, 
        'SoundRec.exe, CalculatorApp.exe, calc.exe, 
        'notepad.exe, rundll32.exe, dllhost.exe, 
        'mspaint.exe, wmplayer.exe, Video.UI.exe, 
        'SnippingTool.exe

        UseMoveV = 0
        MovedV = 0
        Dim disi As Graphics = Me.CreateGraphics()
        'Me.Height = 39
        'Me.Width = 184
        If disi.DpiX <= 96 Then
            Me.Height = 383
            Me.Width = 640
        Else
            Me.Height = 383 * disi.DpiY * 0.01 * 1.05
            Me.Width = 640 * disi.DpiX * 0.01 * 1.05
        End If
        'Me.Height = Label1.Height
        'Me.Width = Label1.Width
        'a.X = (System.Windows.Forms.SystemInformation.PrimaryMonitorSize.Width - Me.Width) - 3 * disi.DpiX * 0.01
        If System.Windows.Forms.SystemInformation.PrimaryMonitorSize.Width - Me.Width <> 0 Then
            a.X = (System.Windows.Forms.SystemInformation.PrimaryMonitorSize.Width - Me.Width) / 2
        Else
            a.X = 1
        End If
        If System.Windows.Forms.SystemInformation.PrimaryMonitorSize.Height - Me.Height <> 0 Then
            a.Y = (System.Windows.Forms.SystemInformation.PrimaryMonitorSize.Height - Me.Height) / 2
        Else
            a.Y = 1
        End If
        Me.Location = a
        RestartStateV = 0
        ShutdownStateV = 0
        RenS = 0
        CurState = 0
        'ContextMenuStrip1.Font = New Font(ContextMenuStrip1.Font.Name, 8.25F * 96.0F / CreateGraphics().DpiX, ContextMenuStrip1.Font.Style, ContextMenuStrip1.Font.Unit, ContextMenuStrip1.Font.GdiCharSet, ContextMenuStrip1.Font.GdiVerticalFont)
        'Font = New Font(Font.Name, 8.25F * 96.0F / CreateGraphics().DpiX, Font.Style, Font.Unit, Font.GdiCharSet, Font.GdiVerticalFont)
    End Sub

    'Private Sub Me_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles Me.FormClosing
    '    'e.Cancel = True
    '    Select Case (e.CloseReason)
    '        '应用程序要求关闭窗口
    '        Case CloseReason.ApplicationExitCall
    '            e.Cancel = False '不拦截，响应操作
    '            '自身窗口上的关闭按钮
    '        Case CloseReason.FormOwnerClosing
    '            e.Cancel = True '拦截，不响应操作
    '            'MDI窗体关闭事件
    '        Case CloseReason.MdiFormClosing
    '            e.Cancel = True '拦截，不响应操作
    '            '不明原因的关闭
    '        Case CloseReason.None
    '            e.Cancel = False
    '            '任务管理器关闭进程
    '        Case CloseReason.TaskManagerClosing
    '            e.Cancel = True '拦截，不响应操作
    '            '用户通过UI关闭窗口或者通过Alt+F4关闭窗口
    '        Case CloseReason.UserClosing
    '            e.Cancel = True '拦截，不响应操作
    '            '操作系统准备关机()
    '        Case (CloseReason.WindowsShutDown)
    '            e.Cancel = False '不拦截，响应操作
    '    End Select

    'End Sub

    'Private Sub Me_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs) Handles Me.FormClosed
    'Me.Dispose()
    'End Sub

    '重启
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        If RestartStateV = 0 Then
            RestartStateV = 1
            Button2.Enabled = False
            Form2.Button3.Enabled = False
            Timer3.Enabled = True
            CurState = 1
            RenS = 15
            Button1.Text = "取消(15s)"
        Else
            RestartStateV = 0
            Button2.Enabled = True
            Form2.Button3.Enabled = True
            Timer3.Enabled = False
            CurState = 0
            RenS = 0
            Button1.Text = "重启"
        End If
    End Sub
    '关机
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        If ShutdownStateV = 0 Then
            ShutdownStateV = 1
            Button1.Enabled = False
            Form2.Button3.Enabled = False
            Timer3.Enabled = True
            CurState = 2
            RenS = 15
            Button2.Text = "取消(15s)"
        Else
            ShutdownStateV = 0
            Button1.Enabled = True
            'Button1.Locked = False
            Form2.Button3.Enabled = True
            Timer3.Enabled = False
            CurState = 0
            RenS = 0
            Button2.Text = "关机"
        End If
    End Sub

    Private Sub Timer3_Tick(sender As System.Object, e As System.EventArgs) Handles Timer3.Tick
        If RenS = 0 Then
            RenS = RenS - 1
            If CurState = 1 Then 'Restart
                Shell("shutdown.exe /r /t 0 /f", AppWinStyle.Hide)
            ElseIf CurState = 2 Then 'Shutdown
                Shell("shutdown.exe /s /t 0 /f", AppWinStyle.Hide)
            End If
        Else
            RenS = RenS - 1
            If CurState = 1 Then 'Restart
                Button1.Text = "取消(" & RenS & "s)"
            ElseIf CurState = 2 Then 'Shutdown
                Button2.Text = "取消(" & RenS & "s)"
            End If
        End If
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Form2.ShowDialog()
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        If Command().ToLower = "/miniboot" Then
            Me.Close()
            BootForm.WindowState = FormWindowState.Normal
            BootForm.Show()
        Else
            End
        End If
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        'SendMessage(-1, 422, 170560, 2)
        'Shell("powershell (Add-Type '[DllImport(\""user32.dll\"")]^public static extern int SendMessage(int hWnd, int hMsg, int wParam, int lParam);' -Name a -Pas)::SendMessage(-1,0x0112,0xF170,2)", AppWinStyle.Hide, False)
        ChangeMonitorState(MonitorMode.MonitorOff)
    End Sub

    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        Shell("powershell ""[Void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms');[System.Windows.Forms.Application]::SetSuspendState('Suspend', $false, $false);""", AppWinStyle.Hide)
    End Sub

    Private Sub Button7_Click(sender As System.Object, e As System.EventArgs) Handles Button7.Click
        Shell("rundll32 user32.dll,LockWorkStation", AppWinStyle.Hide)
    End Sub

    Private Sub Button8_Click(sender As System.Object, e As System.EventArgs) Handles Button8.Click
        If MessageBox.Show("你确定休眠吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Shell("rundll32 powrProf.dll,SetSuspendState", AppWinStyle.Hide)
        End If
    End Sub
    Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
    Private Sub Button9_Click(sender As System.Object, e As System.EventArgs) Handles Button9.Click
        BlackForm.TopMost = True
        BlackForm.Show()
        ChangeMonitorState(MonitorMode.MonitorOff)
    End Sub

    Private Sub Button10_Click(sender As System.Object, e As System.EventArgs) Handles Button10.Click
        BlackForm.TopMost = True
        BlackForm.ShowDialog()
    End Sub

    Private Sub Button11_Click(sender As System.Object, e As System.EventArgs) Handles Button11.Click
        FakeShutdownForm.PictureBox1.Visible = True
        FakeShutdownForm.Label1.Visible = True
        FakeShutdownForm.Timer1.Enabled = False
        FakeShutdownForm.ShowDialog()
    End Sub

    Private Declare Function timeGetTime Lib "winmm.dll" () As Long
    Private Sub Button12_Click(sender As System.Object, e As System.EventArgs) Handles Button12.Click
        Me.Hide()
        Try
            For Each TargetNamea As String In NavTargetNames
                Shell("taskkill.exe /f /im " & TargetNamea & ".exe", AppWinStyle.Hide)
                Shell("taskkill.exe /f /im *" & TargetNamea & "*", AppWinStyle.Hide)
            Next

            For Each TargetName As String In NavTargetNames
                'Dim TargetName As String = "fmp" '存储进程名为文本型，注：进程名不加扩展名
                Dim TargetKill() As Process = Process.GetProcessesByName(TargetName) '从进程名获取进程
                Dim TargetPath As String '存储进程路径为文本型
                If TargetKill.Length > 1 Then '判断进程名的数量，如果同名进程数量在2个以上，用For循环关闭进程。
                    For i = 0 To TargetKill.Length - 1
                        TargetPath = TargetKill(i).MainModule.FileName
                        TargetKill(i).Kill()
                    Next
                    'ElseIf TargetKill.Length = 0 Then '判断进程名的数量，没有发现进程直接弹窗。不需要的，可直接删掉该If子句
                    '   Exit Sub
                ElseIf TargetKill.Length = 1 Then '判断进程名的数量，如果只有一个，就不用For循环
                    TargetKill(0).Kill()
                End If
                'Me.Dispose(1) '关闭自身进程
            Next
        Catch ex As Exception
        End Try

        FakeShutdownForm.Timer1.Enabled = True
        FakeShutdownForm.ShowDialog()
        If Command().ToLower = "/miniboot" Then
            Me.Close()
            BootForm.WindowState = FormWindowState.Normal
            BootForm.Show()
        Else
            End
        End If
    End Sub

    Private Sub Button13_Click(sender As System.Object, e As System.EventArgs) Handles Button13.Click
        If MessageBox.Show("确定进入希沃纯净模式吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

            Try
                For Each TargetNamea As String In NavTargetNames
                    Shell("taskkill.exe /f /im " & TargetNamea & ".exe", AppWinStyle.Hide)
                    Shell("taskkill.exe /f /im *" & TargetNamea & "*", AppWinStyle.Hide)
                Next

                For Each TargetName As String In NavTargetNames
                    'Dim TargetName As String = "fmp" '存储进程名为文本型，注：进程名不加扩展名
                    Dim TargetKill() As Process = Process.GetProcessesByName(TargetName) '从进程名获取进程
                    Dim TargetPath As String '存储进程路径为文本型
                    If TargetKill.Length > 1 Then '判断进程名的数量，如果同名进程数量在2个以上，用For循环关闭进程。
                        For i = 0 To TargetKill.Length - 1
                            TargetPath = TargetKill(i).MainModule.FileName
                            TargetKill(i).Kill()
                        Next
                        'ElseIf TargetKill.Length = 0 Then '判断进程名的数量，没有发现进程直接弹窗。不需要的，可直接删掉该If子句
                        '   Exit Sub
                    ElseIf TargetKill.Length = 1 Then '判断进程名的数量，如果只有一个，就不用For循环
                        TargetKill(0).Kill()
                    End If
                    'Me.Dispose(1) '关闭自身进程
                Next
            Catch ex As Exception
            End Try

            Shell("taskkill.exe /f /im UsefulControl.exe", AppWinStyle.Hide)
            End
        End If

    End Sub

    Private Sub Button14_Click(sender As System.Object, e As System.EventArgs) Handles Button14.Click
        If MessageBox.Show("确定关闭课件吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Try
                For Each TargetNamea As String In DocTargetNames
                    Shell("taskkill.exe /f /im " & TargetNamea & ".exe", AppWinStyle.Hide)
                    Shell("taskkill.exe /f /im *" & TargetNamea & "*", AppWinStyle.Hide)
                Next

                For Each TargetName As String In DocTargetNames
                    'Dim TargetName As String = "fmp" '存储进程名为文本型，注：进程名不加扩展名
                    Dim TargetKill() As Process = Process.GetProcessesByName(TargetName) '从进程名获取进程
                    Dim TargetPath As String '存储进程路径为文本型
                    If TargetKill.Length > 1 Then '判断进程名的数量，如果同名进程数量在2个以上，用For循环关闭进程。
                        For i = 0 To TargetKill.Length - 1
                            TargetPath = TargetKill(i).MainModule.FileName
                            TargetKill(i).Kill()
                        Next
                        'ElseIf TargetKill.Length = 0 Then '判断进程名的数量，没有发现进程直接弹窗。不需要的，可直接删掉该If子句
                        '   Exit Sub
                    ElseIf TargetKill.Length = 1 Then '判断进程名的数量，如果只有一个，就不用For循环
                        TargetKill(0).Kill()
                    End If
                    'Me.Dispose(1) '关闭自身进程
                Next
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub Button15_Click(sender As System.Object, e As System.EventArgs) Handles Button15.Click
        Me.Hide()
        LockTimeForm.ShowDialog()
        If Command().ToLower = "/miniboot" Then
            Me.Close()
            BootForm.WindowState = FormWindowState.Normal
            BootForm.Show()
        Else
            End
        End If
    End Sub

    Private Sub Button16_Click(sender As System.Object, e As System.EventArgs) Handles Button16.Click
        Me.Hide()
        LockTime2Form.ShowDialog()
        If Command().ToLower = "/miniboot" Then
            Me.Close()
            BootForm.WindowState = FormWindowState.Normal
            BootForm.Show()
        Else
            End
        End If
    End Sub

    Private Sub Button17_Click(sender As System.Object, e As System.EventArgs) Handles Button17.Click
        Me.Hide()
        PBoardForm.ShowDialog()
        If Command().ToLower = "/miniboot" Then
            Me.Close()
            BootForm.WindowState = FormWindowState.Normal
            BootForm.Show()
        Else
            End
        End If
    End Sub

    Private Sub Button18_Click(sender As System.Object, e As System.EventArgs) Handles Button18.Click
        Me.Hide()
        PBoard2Form.ShowDialog()
        If Command().ToLower = "/miniboot" Then
            Me.Close()
            BootForm.WindowState = FormWindowState.Normal
            BootForm.Show()
        Else
            End
        End If
    End Sub

    Private Sub Button19_Click(sender As System.Object, e As System.EventArgs) Handles Button19.Click
        Me.Hide()
        IBoardpfrm.ShowDialog()
        If Command().ToLower = "/miniboot" Then
            Me.Close()
            BootForm.WindowState = FormWindowState.Normal
            BootForm.Show()
        Else
            End
        End If
    End Sub

    Private Sub Button20_Click(sender As System.Object, e As System.EventArgs) Handles Button20.Click
        Me.Hide()
        Try
            For Each TargetNamea As String In NavTargetNames
                Shell("taskkill.exe /f /im " & TargetNamea & ".exe", AppWinStyle.Hide)
                Shell("taskkill.exe /f /im *" & TargetNamea & "*", AppWinStyle.Hide)
            Next

            For Each TargetName As String In NavTargetNames
                'Dim TargetName As String = "fmp" '存储进程名为文本型，注：进程名不加扩展名
                Dim TargetKill() As Process = Process.GetProcessesByName(TargetName) '从进程名获取进程
                Dim TargetPath As String '存储进程路径为文本型
                If TargetKill.Length > 1 Then '判断进程名的数量，如果同名进程数量在2个以上，用For循环关闭进程。
                    For i = 0 To TargetKill.Length - 1
                        TargetPath = TargetKill(i).MainModule.FileName
                        TargetKill(i).Kill()
                    Next
                    'ElseIf TargetKill.Length = 0 Then '判断进程名的数量，没有发现进程直接弹窗。不需要的，可直接删掉该If子句
                    '   Exit Sub
                ElseIf TargetKill.Length = 1 Then '判断进程名的数量，如果只有一个，就不用For循环
                    TargetKill(0).Kill()
                End If
                'Me.Dispose(1) '关闭自身进程
            Next
        Catch ex As Exception
        End Try

        BlackForm.TopMost = False
        BlackForm.ShowDialog()
        If Command().ToLower = "/miniboot" Then
            Me.Close()
            BootForm.WindowState = FormWindowState.Normal
            BootForm.Show()
        Else
            End
        End If
    End Sub

    Private Sub Button21_Click(sender As System.Object, e As System.EventArgs) Handles Button21.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
End Class
