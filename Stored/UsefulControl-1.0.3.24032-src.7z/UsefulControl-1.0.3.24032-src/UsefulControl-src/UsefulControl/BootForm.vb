﻿Public Class BootForm
    Public EnbClose As Integer
    Public a As New System.Drawing.Point
    Public MovedV As Integer
    Public UseMoveV As Integer
    Public b As Integer
    Public disi As System.Drawing.Graphics
    Public NavTargetNames(27) As String
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub BootForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        NavTargetNames(0) = "TimeControl"
        NavTargetNames(1) = "PowerControl"
        NavTargetNames(2) = "TDocKiller"
        NavTargetNames(3) = "IBoard"
        NavTargetNames(4) = "LockTime"
        NavTargetNames(5) = "PBoard"
        NavTargetNames(6) = "LockTime2"
        NavTargetNames(7) = "PBoard2"
        NavTargetNames(8) = "TimeControl64"
        NavTargetNames(9) = "PowerControl64"
        NavTargetNames(10) = "TDocKiller64"
        NavTargetNames(11) = "IBoard64"
        NavTargetNames(12) = "LockTime64"
        NavTargetNames(13) = "PBoard64"
        NavTargetNames(14) = "LockTime264"
        NavTargetNames(15) = "PBoard264"

        NavTargetNames(16) = "PPTService"
        NavTargetNames(17) = "SeewoCore"
        NavTargetNames(18) = "SeewoFreezeUpdateAssist"
        NavTargetNames(19) = "proxyLayerService"
        NavTargetNames(20) = "ResidentSideBar.Defender"
        NavTargetNames(21) = "ResidentSideBar"
        NavTargetNames(22) = "LastContainer"
        NavTargetNames(23) = "LastContainerDaemon"
        NavTargetNames(24) = "EasiRecorder"
        NavTargetNames(25) = "seewoPincoTeacher"
        NavTargetNames(26) = "seewoPincoTeacherService"
        NavTargetNames(27) = "PincoMirror"
        Dim Uif As Integer
        Uif = 0
        If Command().ToLower = "/blackscr" Then
            Me.WindowState = FormWindowState.Minimized
            BlackForm.TopMost = True
            BlackForm.ShowDialog()
            Uif = 1
            End
        ElseIf Command().ToLower = "/closescr" Then
            Me.WindowState = FormWindowState.Minimized
            Form1.ChangeMonitorState(Form1.MonitorMode.MonitorOff)
            Uif = 1
            BlackForm.TopMost = True
            BlackForm.ShowDialog()
            End
        ElseIf Command().ToLower = "/fakeshutdown" Then
            Me.WindowState = FormWindowState.Minimized
            Me.Hide()
            Me.Visible = False

            Try
                For Each TargetNamea As String In NavTargetNames
                    Shell("taskkill.exe /f /im " & TargetNamea & ".exe", AppWinStyle.Hide)
                    Shell("taskkill.exe /f /im *" & TargetNamea & "*", AppWinStyle.Hide)
                Next

                For Each TargetName As String In NavTargetNames
                    'Dim TargetName As String = "fmp" '存储进程名为文本型，注：进程名不加扩展名
                    Dim TargetKill() As Process = Process.GetProcessesByName(TargetName) '从进程名获取进程
                    Dim TargetPath As String '存储进程路径为文本型
                    If TargetKill.Length > 1 Then '判断进程名的数量，如果同名进程数量在2个以上，用For循环关闭进程。
                        For i = 0 To TargetKill.Length - 1
                            TargetPath = TargetKill(i).MainModule.FileName
                            TargetKill(i).Kill()
                        Next
                        'ElseIf TargetKill.Length = 0 Then '判断进程名的数量，没有发现进程直接弹窗。不需要的，可直接删掉该If子句
                        '   Exit Sub
                    ElseIf TargetKill.Length = 1 Then '判断进程名的数量，如果只有一个，就不用For循环
                        TargetKill(0).Kill()
                    End If
                    'Me.Dispose(1) '关闭自身进程
                Next
            Catch ex As Exception
            End Try


            FakeShutdownForm.Timer1.Enabled = True
            Uif = 1
            FakeShutdownForm.ShowDialog()
            End
            'ElseIf Command().ToLower = "/fakeshutdownui" Then
            '    FakeShutdownForm.PictureBox1.Visible = True
            '    FakeShutdownForm.Label1.Visible = True
            '    Me.WindowState = FormWindowState.Minimized
            '    FakeShutdownForm.Timer1.Enabled = False
            '    FakeShutdownForm.ShowDialog()
            '    End
        ElseIf Command().ToLower = "/locktime" Then
            Me.WindowState = FormWindowState.Minimized
            Me.Hide()
            Me.Visible = False
            Uif = 1
            LockTimeForm.ShowDialog()
            End
        ElseIf Command().ToLower = "/locktime2" Then
            Me.WindowState = FormWindowState.Minimized
            Me.Hide()
            Me.Visible = False
            Uif = 1
            LockTime2Form.ShowDialog()
            End
        ElseIf Command().ToLower = "/pboard" Then
            Me.WindowState = FormWindowState.Minimized
            Me.Hide()
            Me.Visible = False
            Uif = 1
            PBoardForm.ShowDialog()
            End
        ElseIf Command().ToLower = "/pboard2" Then
            Me.WindowState = FormWindowState.Minimized
            Me.Hide()
            Me.Visible = False
            Uif = 1
            PBoard2Form.ShowDialog()
            End
        ElseIf Command().ToLower = "/iboard" Then
            Me.WindowState = FormWindowState.Minimized
            Me.Hide()
            Me.Visible = False
            Uif = 1
            IBoardpfrm.ShowDialog()
            End
        ElseIf Command().ToLower = "/volup" Then
            Me.WindowState = FormWindowState.Minimized
            Me.Hide()
            Me.Visible = False
            Uif = 1
            Call Form1.SendMessageW(Me.Handle, Form1.WM_APPCOMMAND, Me.Handle, New IntPtr(Form1.up))
            End
        ElseIf Command().ToLower = "/voldown" Then
            Me.WindowState = FormWindowState.Minimized
            Me.Hide()
            Me.Visible = False
            Uif = 1
            Call Form1.SendMessageW(Me.Handle, Form1.WM_APPCOMMAND, Me.Handle, New IntPtr(Form1.down))
            End
        ElseIf Command().ToLower = "/volmute" Then
            Me.WindowState = FormWindowState.Minimized
            Me.Hide()
            Me.Visible = False
            Uif = 1
            Call Form1.SendMessageW(Me.Handle, Form1.WM_APPCOMMAND, Me.Handle, New IntPtr(Form1.mute))
            End
        ElseIf Command().ToLower = "/blacku" Then
            Me.WindowState = FormWindowState.Minimized
            Me.Hide()
            Me.Visible = False
            Uif = 1
            Try
                For Each TargetNamea As String In NavTargetNames
                    Shell("taskkill.exe /f /im " & TargetNamea & ".exe", AppWinStyle.Hide)
                    Shell("taskkill.exe /f /im *" & TargetNamea & "*", AppWinStyle.Hide)
                Next

                For Each TargetName As String In NavTargetNames
                    'Dim TargetName As String = "fmp" '存储进程名为文本型，注：进程名不加扩展名
                    Dim TargetKill() As Process = Process.GetProcessesByName(TargetName) '从进程名获取进程
                    Dim TargetPath As String '存储进程路径为文本型
                    If TargetKill.Length > 1 Then '判断进程名的数量，如果同名进程数量在2个以上，用For循环关闭进程。
                        For i = 0 To TargetKill.Length - 1
                            TargetPath = TargetKill(i).MainModule.FileName
                            TargetKill(i).Kill()
                        Next
                        'ElseIf TargetKill.Length = 0 Then '判断进程名的数量，没有发现进程直接弹窗。不需要的，可直接删掉该If子句
                        '   Exit Sub
                    ElseIf TargetKill.Length = 1 Then '判断进程名的数量，如果只有一个，就不用For循环
                        TargetKill(0).Kill()
                    End If
                    'Me.Dispose(1) '关闭自身进程
                Next
            Catch ex As Exception
            End Try

            BlackForm.TopMost = False
            BlackForm.ShowDialog()
            End
        End If
        If Uif <> 1 Then
            If Command().ToLower = "/miniboot" Then
                Dim createdNew As Boolean
                Dim mutex As System.Threading.Mutex = New System.Threading.Mutex(True, "UsefulControl", createdNew)
                If createdNew = False Then
                    End
                End If
                mutex.ReleaseMutex()
            ElseIf Command().ToLower = "/minibootleft" Then
                Dim createdNew As Boolean
                Dim mutex As System.Threading.Mutex = New System.Threading.Mutex(True, "UsefulControl", createdNew)
                If createdNew = False Then
                    End
                End If
                mutex.ReleaseMutex()
            ElseIf Command().ToLower = "/minibootright" Then
                Dim createdNew As Boolean
                Dim mutex As System.Threading.Mutex = New System.Threading.Mutex(True, "UsefulControl", createdNew)
                If createdNew = False Then
                    End
                End If
                mutex.ReleaseMutex()
            Else
                Me.WindowState = FormWindowState.Minimized
                Me.Hide()
                Me.Visible = False
                Form1.ShowDialog()
                End
            End If

        End If

        EnbClose = 0
        UseMoveV = 0
        MovedV = 0
        disi = Me.CreateGraphics()
        Timer1.Enabled = True
        'Me.Height = 39
        'Me.Width = 184
      



        If Command() <> "" Then
            If Command() = "/minibootleft" Then
                If disi.DpiX <= 96 Then
                    Me.Height = 118
                    Me.Width = 29
                Else
                    Me.Height = 118 * disi.DpiY * 0.01 '* 1.05
                    Me.Width = 28 * disi.DpiX * 0.01 '* 1.05
                End If
            ElseIf Command() = "/minibootright" Then
                If disi.DpiX <= 96 Then
                    Me.Height = 118
                    Me.Width = 29
                Else
                    Me.Height = 118 * disi.DpiY * 0.01 '* 1.05
                    Me.Width = 29 * disi.DpiX * 0.01 '* 1.05
                End If
            Else
                If disi.DpiX <= 96 Then
                    Me.Height = 28
                    Me.Width = 88
                Else
                    Me.Height = 28 * disi.DpiY * 0.01 '* 1.05
                    Me.Width = 88 * disi.DpiX * 0.01 '* 1.05
                End If
            End If
        Else
            If disi.DpiX <= 96 Then
                Me.Height = 28
                Me.Width = 88
            Else
                Me.Height = 28 * disi.DpiY * 0.01 '* 1.05
                Me.Width = 88 * disi.DpiX * 0.01 '* 1.05
            End If
        End If


        If Command() = "/miniboot" Then
            Me.Button1.Text = "小工具>..."
        Else
            Me.Button1.Text = "小工具"
        End If

        If Command() <> "" Then
            If Command() = "/miniboot" Then
                a.X = 3 * disi.DpiX * 0.01
                a.Y = 3 * disi.DpiX * 0.01
            ElseIf Command() = "/minibootleft" Then
                a.X = 3 * disi.DpiX * 0.01
                a.Y = (System.Windows.Forms.SystemInformation.PrimaryMonitorSize.Height - Me.Height) / 2
            ElseIf Command() = "/minibootright" Then
                a.X = (System.Windows.Forms.SystemInformation.PrimaryMonitorSize.Width - Me.Width) - 3 * disi.DpiX * 0.01
                a.Y = (System.Windows.Forms.SystemInformation.PrimaryMonitorSize.Height - Me.Height) / 2
            Else
                a.X = 3 * disi.DpiX * 0.01
                a.Y = (System.Windows.Forms.SystemInformation.PrimaryMonitorSize.Height - Me.Height) / 2
            End If
        Else
            a.X = 3 * disi.DpiX * 0.01
            a.Y = 3 * disi.DpiX * 0.01
        End If

        Me.Location = a
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If MovedV <> 1 Then
            If Me.Location <> a Then
                Me.Location = a
            End If
        End If
    End Sub
    'API移动窗体
    Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Boolean
    Declare Function ReleaseCapture Lib "user32" Alias "ReleaseCapture" () As Boolean
    Const WM_SYSCOMMAND = &H112
    Const SC_MOVE = &HF010&
    Const HTCAPTION = 2
    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        If UseMoveV = 1 Then
            ReleaseCapture()
            SendMessage(Me.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0)
            MovedV = 1
        End If
    End Sub
    Private Sub Button1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Button1.MouseDown
        If UseMoveV = 1 Then
            ReleaseCapture()
            SendMessage(Me.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0)
            MovedV = 1
        End If
    End Sub

    Private Sub h30s_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles h30s.Click
        Timer2.Interval = 30000
        Me.Hide()
        Timer2.Enabled = True
    End Sub

    Private Sub h1m_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles h1m.Click
        Timer2.Interval = 60000
        Me.Hide()
        Timer2.Enabled = True
    End Sub

    Private Sub h5m_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles h5m.Click
        Timer2.Interval = 300000
        Me.Hide()
        Timer2.Enabled = True
    End Sub

    Private Sub h10m_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles h10m.Click
        Timer2.Interval = 600000
        Me.Hide()
        Timer2.Enabled = True
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Me.Show()
        Timer2.Enabled = False
    End Sub
    Private Sub ext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ext.Click
        'If MessageBox.Show("确定要关闭时钟吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = MsgBoxResult.Yes Then
        'End
        'End If
        Form2.ShowDialog()
    End Sub

    Private Sub Me_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles Me.FormClosing
        If EnbClose <> 1 Then
            'e.Cancel = True
            Select Case (e.CloseReason)
                '应用程序要求关闭窗口
                Case CloseReason.ApplicationExitCall
                    e.Cancel = False '不拦截，响应操作
                    '自身窗口上的关闭按钮
                Case CloseReason.FormOwnerClosing
                    e.Cancel = True '拦截，不响应操作
                    'MDI窗体关闭事件
                Case CloseReason.MdiFormClosing
                    e.Cancel = True '拦截，不响应操作
                    '不明原因的关闭
                Case CloseReason.None
                    e.Cancel = False
                    '任务管理器关闭进程
                Case CloseReason.TaskManagerClosing
                    e.Cancel = True '拦截，不响应操作
                    '用户通过UI关闭窗口或者通过Alt+F4关闭窗口
                Case CloseReason.UserClosing
                    e.Cancel = True '拦截，不响应操作
                    '操作系统准备关机()
                Case (CloseReason.WindowsShutDown)
                    e.Cancel = False '不拦截，响应操作
            End Select
        End If

    End Sub

End Class